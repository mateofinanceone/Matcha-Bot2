pkg install nodejs -y
pkg install ffmpeg -y
pkg install imagemagick -y
npm install
